﻿using System;
using System.Linq;

namespace BookstoreUpdated.Models
{
    public interface ICheckoutRepository
    {
        IQueryable<Checkout> Checkout { get; }

        void SaveCart(Checkout c);
    }
}
